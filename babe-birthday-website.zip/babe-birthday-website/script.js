const surpriseButton = document.querySelector('#surprise-button');
const hiddenSections = [...document.querySelectorAll('.hidden-section')];
const heartsLayer = document.querySelector('#hearts-layer');
const reasonMessage = document.querySelector('#reason-message');
const wishButton = document.querySelector('#wish-button');
const wishResult = document.querySelector('#wish-result');
const toast = document.querySelector('#toast');
let surpriseOpened = false;
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

function revealSurprise() {
  surpriseOpened = true;
  hiddenSections.forEach((section, index) => {
    section.classList.add('revealed');
    section.style.animationDelay = `${Math.min(index * 100, 300)}ms`;
  });
  createHeartBurst(24);
  surpriseButton.innerHTML = 'Your surprise is waiting below <span aria-hidden="true">♥</span>';
  surpriseButton.setAttribute('aria-expanded', 'true');
  document.querySelector('#note').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function createHeartBurst(count = 8) {
  const symbols = ['♥', '♡', '✿', '✦'];
  for (let i = 0; i < count; i++) {
    const heart = document.createElement('span');
    heart.className = 'floating-heart';
    heart.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    heart.style.left = `${Math.random() * 100}%`;
    heart.style.fontSize = `${12 + Math.random() * 22}px`;
    heart.style.animationDuration = `${5 + Math.random() * 5}s`;
    heart.style.animationDelay = `${Math.random() * 1.8}s`;
    heartsLayer.appendChild(heart);
    heart.addEventListener('animationend', () => heart.remove(), { once: true });
  }
}

surpriseButton.addEventListener('click', () => {
  if (!surpriseOpened) revealSurprise();
  else document.querySelector('#note').scrollIntoView({ behavior: 'smooth', block: 'start' });
});

document.querySelectorAll('.reason-card').forEach((card) => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.reason-card').forEach((other) => other.classList.remove('selected'));
    card.classList.add('selected');
    reasonMessage.textContent = card.dataset.message;
    createHeartBurst(5);
  });
});

wishButton.addEventListener('click', () => {
  wishResult.textContent = 'I hope your wish finds its way to you, Babe. You deserve beautiful things. 💗';
  wishButton.textContent = 'Wish sent into the universe ✨';
  wishButton.disabled = true;
  createHeartBurst(30);
  showToast('A little wish, wrapped in love. ♡');
});

document.querySelector('#again-button').addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
  createHeartBurst(12);
});

// A few gentle floating hearts are present from the start.
createHeartBurst(10);
