# Happy Birthday, Babe 💗

A responsive romantic birthday website built with plain HTML, CSS, and JavaScript. No build tools or package installation required.

## File structure

```text
babe-birthday-website/
├── index.html   # Page content and sections
├── style.css    # Colors, layout, responsive design, animations
├── script.js    # Surprise button, cards, wish button, floating hearts
└── README.md    # This guide
```

## Run it on your computer

1. Download and unzip the project.
2. Open the `babe-birthday-website` folder.
3. Double-click `index.html` to open it in your browser.
4. For a nicer developer workflow, open the folder in VS Code and use the **Live Server** extension, then click **Go Live**.

There are no npm packages or build steps. An internet connection is used only to load the Google Fonts; the page itself works without it using fallback fonts.

## Personalize it before sharing

Open `index.html` and edit the letter, the three reminder-card messages, and the final signature so they sound like you. Search for phrases such as `Your person`, `My dearest Babe`, and `Thank you for being you`.

To add photos later, put image files in this folder and add an `<img src="your-photo.jpg" alt="A favorite memory">` where you want the photo to appear. Keep the file names simple and use lowercase letters.

## Publish a shareable link with GitHub Pages

1. Create or sign in to a GitHub account at https://github.com/.
2. Create a **new public repository**, for example `birthday-for-babe`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository's root folder (you can also upload `README.md`). Do not upload the ZIP file in place of these files.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. GitHub Pages will show a public URL similar to `https://YOUR-USERNAME.github.io/birthday-for-babe/`.
8. Open that URL on your phone to test it, then send the link to her on WhatsApp.

GitHub's menus can change slightly. The repository must include `index.html` at its root for this setup to work. A public repository means the source code is publicly viewable, so do not put private details or sensitive photos in it unless you are comfortable with that.

## Alternative: Netlify Drop

You can also sign in to https://app.netlify.com/drop and drag the project folder (or a ZIP containing the site files) into the drop area. Follow Netlify's prompts to publish and get a shareable URL. Check the current Netlify flow if the interface differs.

## Quick checklist

- [ ] Replace generic lines with your own words.
- [ ] Test the surprise button and each reminder card.
- [ ] Check the page on a phone-sized screen.
- [ ] Publish and open the public link yourself before sending it.
